import time
import pygame

WIDTH = 1000
HEIGHT = 618
FPS = 1

# define colors
white = (255, 255, 255)
BLACK = (0, 0, 0)
RED = (255, 0, 0)
GREEN = (0, 255, 0)
BLUE = (0, 0, 255)

# initialize pygame and create window
pygame.init()
pygame.mixer.init()
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("My Game")
clock = pygame.time.Clock()

ttf = pygame.font.Font("minecraft.ttf", 25)
textImage = ttf.render("pygame", True, white)
# 初始化
running = True
count = 0
seconds = 0
minutes = 0
start = time.time()


while running:
    # keep loop running at the right speed
    clock.tick(FPS)
    # Process input (events)
    for event in pygame.event.get():
        # check for closing window
        if event.type == pygame.QUIT:
            running = False

    seconds = seconds + 1
    # 进位
    if seconds >= 60:
        seconds = 0
        minutes = minutes+1
    # 秒
    if seconds >= 10 > minutes:
        time_text = "录制中                                                                                                                                   11:0"+str(minutes)+":"+str(seconds)
    elif seconds >= 10 < minutes:
        time_text = "录制中                                                                                                                                   11:" + str(minutes) + ":" + str(seconds)
    elif seconds <= 10 < minutes:
        time_text = "录制中                                                                                                                                   11:" + str(minutes) + ":0" + str(seconds)
    elif seconds <= 10 > minutes:
        time_text = "录制中                                                                                                                                   11:0"+str(minutes)+":0"+str(seconds)
    else:
        time_text = "录制中                                                                                                                                   11:45:0" + str(seconds)
    screen.fill(BLACK)
    replay = ttf.render(time_text, True, white)
    screen.blit(replay, (10,10))

    # 屏幕更新
    pygame.display.flip()

pygame.quit()
